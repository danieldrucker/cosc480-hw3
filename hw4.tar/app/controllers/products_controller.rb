class ProductsController < ApplicationController
=begin
    def index
        puts "~~~~~~~~~~~~~~~~~~~~~~~~~~~~        #{session[:ind]}"
        @products = Product.all
        age, price = ""
        index = params[:index] and session[:ind] = params[:index] unless params.has_key?(:index)
        index = session[:ind] if params.has_key?(:index) == false and session.has_key?(:ind)
        if index.nil? == false 
            age = index[:minimum_age_appropriate] if index.has_key?(:minimum_age_appropriate)
            price = index[:price] if index.has_key?(:price)
            @products = @products.filter_by(age, price)
        end

        order = "name"
        order = params[:sort] and session[:sort] = params[:sort] if params.has_key?(:sort)
        order = session[:sort] if session.has_key?(:sort)
        @products = @products.sorted_by(order)
        
    end
=end
    def index
        @products = Product.all
        if params.has_key?(:index)
            filter = params[:index]
            session[:filter] = params[:index]
        elsif session.has_key?(:filter)
            filter= session[:filter]
            puts "Using SESSION"
        else
            filter, session[:filter] = {:minimum_age_appropriate => "", :price => ""}
        end
        age = filter.values[0]
        price = filter.values[1]
        puts "~~~~~~~~~~~~~~~~~~~~~~~~~~~~Age     #{filter.values[1]}"
        puts "~~~~~~~~~~~~~~~~~~~~~~~~~~~~Pri     #{filter[:price]}"
        puts "~~~~~~~~~~~~~~~~~~~~~~~~~~~~all     #{filter}"
        @products = Product.all.filter_by(age, price)

        order = "name"
        if params.has_key?(:sort)
            order = params[:sort]
            session[:sort] = params[:sort]
        elsif session.has_key?(:sort)
            order = session[:sort]
        end

        @products = @products.sorted_by(order)

    end
            

    def show
        id = params[:id]
        @product = Product.find(id)
    end
 
    def new 

    end

    def edit
        id = params[:id]
        @product = Product.find(id)

    end

    def create
        p = Product.new(create_update_params) # "mass assignment" of attributes!
        if p.save
            flash[:notice] = "Product #{p.name} successfully created"
            redirect_to products_path
        else
            flash[:alert] = "Product couldn't be created"
            redirect_to new_product_path
        end
    end
 
    def update
        @product = Product.find params[:id]
        @product.assign_attributes(create_update_params)
        if @product.save
            flash[:notice] = "#{@product.name} was successfully updated."
            redirect_to product_path(@product)
        else
            flash[:alert] = "Product could not be updated"
            redirect_to edit_product_path(@product)
        end
    end

    def create_update_params
        params.require(:product).permit(:name, :description, :price, :minimum_age_appropriate, :maximum_age_appropriate, :image)
    end

end
